contents:

bootstrap.min.js
jquery.min.js
w3.css
jquery-3.1.1.js
font-awesome-4.7.0